
import imgsrcx from "../Images/lion.png"
import imgsrcy from "../Images/imgsrc02.png"
import imgsrcz from "../Images/imgsrc03.png"
import imgsrct from "../Images/tiger.png"
import imgsrce from "../Images/elephant.png"
import imgsrch from "../Images/hippo.png"
    


export const Sdata = [
    {
        imgsrc : imgsrcx,
        titles : "Lion King"
    },
    {
        imgsrc : imgsrcy ,
        titles : "Fish"
    },
    {
        imgsrc : imgsrcz,
        titles : "Fish"
    },
    {
        imgsrc : imgsrct,
        titles : "Tiger"
    },
    {
        imgsrc : imgsrce,
        titles : "Elephant"
    },
    {
        imgsrc : imgsrch,
        titles : "Hippo"
    },
]
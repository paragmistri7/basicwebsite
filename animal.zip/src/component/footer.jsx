import React from "react";

const Footer = () => {
    return (
      <div className="container-fluid footer_page">
            
    <div className="container footer_animal m-auto">
      <div className="row text-center d-flex justify-content-center m-auto ">
        <div className="">
          Copyright 2021 © Animal.com All Rights Reserved
        </div>
      </div>
    </div>
      </div>
  );
};

export default Footer;
